# bis23b_teacher_version
Code and output files from the winter 2024 bis23b course. 

Uploading lab 4 first. 

# *Hannah Houts*

Graduate Student at UC Davis
!!!
